﻿<?php
   $uploaddir = "./pics/";
   $type=array("jpg","bmp","png");
   $patch="http://123.206.23.189/";
  

    function fileext($filename)
    {
        return substr(strrchr($filename, '.'), 1);
    }

    function random($length)
    {
        $hash = 'CR-';
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
        $max = strlen($chars) - 1;
        mt_srand((double)microtime() * 1000000);
            for($i = 0; $i < $length; $i++)
            {
                $hash .= $chars[mt_rand(0, $max)];
            }
        return $hash;
    }
    $a=strtolower(fileext($_FILES['file']['name']));
    if(!in_array(strtolower(fileext($_FILES['file']['name'])),$type))
    {
        $text=implode(",",$type);
        echo "您只能上传jpg、bmp或者png文件";
    }
 
    else{
    $filename=explode(".",$_FILES['file']['name']);
        do
        {
            $filename[0]=random(10); 
            $name=implode(".",$filename);
            $uploadfile=$uploaddir.$name;
        }
    while(file_exists($uploadfile));
        if (move_uploaded_file($_FILES['file']['tmp_name'],$uploadfile)){

            //echo "文件" . basename( $_FILES["file"]["tmp_name"]). " 已上传";
			echo "<br>";
			//print_r($_FILES["file"]);
			//echo "<img src={$uploadfile}  width='20%' alt='您的图片'></img>"; //以浏览器15%宽度输出图片		
			
			echo "<script>$('#previewing').src='{$uploadfile}';$('#previewing').width='20%';</script>";
			
			echo "<br>";		
			if($_POST['level'] == '1') {
				$cmd = system('python ./python/final.py ' . $uploadfile . ' 1');
			}
			else if($_POST['level'] == '2') {
				$cmd = system('python ./python/final.py ' . $uploadfile . ' 2');
			}
			else if($_POST['level'] == '3') {
				$cmd = system('python ./python/final.py ' . $uploadfile . ' 3');
			}
			
			echo "吸毒后 --> ";
			echo "<br>";
            $afterpath = './afterdrugs/'.$name;
			echo "<img src={$afterpath} alt='处理后' height='55%' width='32%' style='display: block;margin-left: auto;margin-right: auto '></img>";
			
			
			
			
        } else {
            echo "上传失败";
        }

   }
?>